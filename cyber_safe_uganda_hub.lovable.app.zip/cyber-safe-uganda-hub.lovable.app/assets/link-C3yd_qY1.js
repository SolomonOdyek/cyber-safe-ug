import {
    r as e,
    t
} from "./jsx-runtime-BkSabwWG.js";
import {
    t as n
} from "./react-DHmoMYoq.js";
import {
    r,
    t as i
} from "./useSelector-7tZHjEZI.js";
import {
    t as a
} from "./useRouter-Dcm1jW_h.js";

function o(e) {
    return e[e.length - 1]
}

function s(e, t) {
    return typeof e == `function` ? e(t) : e
}
var c = Object.prototype.hasOwnProperty;

function l(e) {
    for (let t in e)
        if (c.call(e, t)) return !0;
    return !1
}
var u = () => Object.create(null),
    d = (e, t) => f(e, t, !0);

function f(e, t, n, r = 0) {
    if (e === t) return e;
    if (r++ > 500) return t;
    let i = Array.isArray(e) && Array.isArray(t);
    if (!i && !(p(e) && p(t))) return t;
    let a = Object.keys(e),
        s = a.length,
        l = Object.keys(t),
        d = l.length;
    if (i ? s !== e.length || d !== t.length || s && o(a) !== `${s-1}` || d && o(l) !== `${d-1}` : s !== Object.getOwnPropertyNames(e).length || d !== Object.getOwnPropertyNames(t).length || Object.getOwnPropertySymbols(t).length) return t;
    let m = 0,
        h, g, _;
    if (i) {
        for (; m < d && (_ = m, g = e[_], h = t[_], h = g === h ? g : typeof g == `object` ? f(g, h, n, r) : h, h === g); m++);
        if (m === d && s === d) return e
    } else {
        let i = s === d,
            o = !0;
        for (; m < d; m++) {
            _ = l[m], g = e[_];
            let s = t[_];
            h = g === s ? g : typeof g == `object` ? f(g, s, n, r) : s, i && = h === g && (a[m] === _ || c.call(e, _)), o && = Object.is(h, s), a[m] = h
        }
        if (i) return Object.getOwnPropertySymbols(e).length ? t : e;
        if (o) return t
    }
    let v = i ? l.fill(0) : n ? u() : {};
    for (let o = 0; o < d; o++) _ = i ? o : l[o], i ? (g = e[_], o > m && (h = t[_], h = g === h ? g : typeof g == `object` ? f(g, h, n, r) : h), v[_] = o < m ? g : h) : v[_] = a[o];
    return v
}

function p(e) {
    return !e || typeof e != `object` ? !1 : (Object.getPrototypeOf(e) ? .constructor ? ? Object) === Object
}

function m(e, t, n, r) {
    if (e === t) return !0;
    if (Array.isArray(e) && Array.isArray(t)) {
        if (e.length !== t.length) return !1;
        for (let i = 0, a = e.length; i < a; i++) {
            let a = e[i],
                o = t[i];
            if (a !== o && !m(a, o, n, r)) return !1
        }
        return !0
    }
    if (p(e) && p(t)) {
        if (n) {
            for (let i in t)
                if ((r || t[i] !== void 0) && !m(e[i], t[i], n, r)) return !1;
            return !0
        }
        let i = 0;
        if (r) i = Object.keys(e).length;
        else
            for (let t in e) e[t] !== void 0 && i++;
        for (let a in t)
            if ((r || t[a] !== void 0) && (i-- === 0 || !m(e[a], t[a], n, r))) return !1;
        return i === 0
    }
    return !1
}

function h(e) {
    return typeof e ? .message == `string` ? e.message.startsWith(`Failed to fetch dynamically imported module`) || e.message.startsWith(`error loading dynamically imported module`) || e.message.startsWith(`Importing a module script failed`) : !1
}
var g = /[\x00-\x1f\x7f"<>`{}]/g;

function _(e) {
    return e.replace(g, e => `%` + e.charCodeAt(0).toString(16).toUpperCase().padStart(2, `0`))
}

function v(e) {
    let t;
    try {
        t = decodeURI(e)
    } catch {
        t = e.replaceAll(/%[0-9A-F]{2}/gi, e => {
            try {
                return decodeURI(e)
            } catch {
                return e
            }
        })
    }
    return _(t)
}
var y = [`http:`, `https:`, `mailto:`, `tel:`];

function b(e) {
    if (e[0] !== `/` && e.includes(`:`)) return /^[\x00-\x20]*([a-z][a-z\d+.\t\n\r-]*:)/i.exec(e) ? .[1] ? .replace(/[\t\n\r]/g, ``).toLowerCase()
}
var x = /^[\x00-\x20]*[\\/][\t\n\r]*[\\/]/;

function S(e, t) {
    if (!e) return !1;
    if (x.test(e)) return !0;
    let n = b(e);
    return n ? !t.has(n) : !1
}
var C = {
        "&": `\\u0026`,
        ">": `\\u003e`,
        "<": `\\u003c`,
        "\u2028": `\\u2028`,
        "\u2029": `\\u2029`
    },
    w = /[&><\u2028\u2029]/g;

function T(e) {
    return e.replace(w, e => C[e])
}

function E(e) {
    if (!e) return e;
    let t = e;
    if (/[%\\\x00-\x1f\x7f]/.test(e)) {
        let n = /%25|%5C/gi,
            r = 0,
            i;
        for (t = ``;
            (i = n.exec(e)) !== null;) t += v(e.slice(r, i.index)) + i[0], r = n.lastIndex;
        t += v(r ? e.slice(r) : e)
    }
    return t
}

function D(e) {
    return /[\s\u0080-\uFFFF]/.test(e) ? e.replace(/\s|[^\u0000-\u007F]/gu, encodeURIComponent) : e
}

function O(e, t) {
    if (e === t) return !0;
    if (e.length !== t.length) return !1;
    for (let n = 0; n < e.length; n++)
        if (e[n] !== t[n]) return !1;
    return !0
}

function k(e) {
    return e.replace(/\/{2,}/g, `/`)
}

function A(e) {
    return e === `/` ? e : e.replace(/^\/+/, ``)
}

function j(e) {
    let t = e.length;
    return t > 1 && e[t - 1] === `/` ? e.replace(/\/+$/, ``) : e
}

function M(e) {
    return j(A(e))
}

function N(e, t) {
    return e ? .endsWith(`/`) && e !== `/` && e !== `${t}/` ? e.slice(0, -1) : e
}

function P(e, t, n = `never`, r) {
    if (t.includes(`//`) && (t = k(t)), t.startsWith(`/`)) return t.length === 1 || n === `preserve` ? t : n === `always` ? t.endsWith(`/`) ? t : `${t}/` : t.endsWith(`/`) ? t.slice(0, -1) : t;
    let i = t === `.`,
        a;
    if (r) {
        a = i ? e : e + `\0` + t;
        let n = r.get(a);
        if (n) return n
    }
    let s;
    if (i) s = e.split(`/`);
    else {
        for (e.includes(`//`) && (e = k(e)), s = e.split(`/`); s.length > 1 && o(s) === ``;) s.pop();
        let n = t.split(`/`);
        for (let e = 0, t = n.length; e < t; e++) {
            let r = n[e];
            r === `` ? e ? e === t - 1 && s.push(r) : s = [r] : r === `..` ? s.length > 1 ? s.pop() : s = [``] : r === `.` || s.push(r)
        }
    }
    s.length > 1 && (o(s) === `` ? n === `never` && s.pop() : n === `always` && s.push(``));
    let c = s.join(`/`),
        l = (i ? k(c) : c) || `/`;
    return a && r && r.set(a, l), l
}

function F(e) {
    let t = new Map(e.map(e => [encodeURIComponent(e), e])),
        n = new RegExp([...t.keys()].join(`|`).replace(/[.*()]/g, `\\$&`), `g`);
    return e => e.replace(n, e => t.get(e) ? ? e)
}

function I(e) {
    return e == null || e === ``
}

function L(e, t, n) {
    if (typeof t != `string`) return `` + (t ? ? void 0);
    let r = e === `_splat`;
    if (r && (!t || /^[a-zA-Z0-9\-._~!/]*$/.test(t))) return t;
    let i = encodeURIComponent(t);
    return r && (i = i.replaceAll(`%2F`, `/`)), n ? n(i) : i
}

function R(e, t, n, r, i) {
    let a = e.endsWith(`/`) ? `/` : ``,
        o = ``;
    for (let e of t) {
        if (typeof e == `string`) {
            o += e;
            continue
        }
        let [t, s, c, l] = e, u = t === 2, d = u && l !== void 0 ? l + a : l, f = n[s];
        if (t !== 3 || f != null) {
            if (i && (i[s] = f, u && (i[`*`] = f)), u && I(f)) {
                if (c === `/` && !d) continue;
                f = ``
            }
            o += c + L(s, f, r) + (d || ``)
        }
    }
    return o + a || `/`
}
var z = `Error preloading route! ☝️`,
    B = e(n(), 1);
t();

function V(...e) {
    let t = B.useRef(e),
        n = t.current;
    return e.forEach((e, t) => {
        m(n[t], e, !1, !0) || (n[t] = e)
    }), t.current
}

function H(e, t) {
    e.preloadRoute(t).catch(e => {
        console.warn(e), console.warn(z)
    })
}
var U = {
    compare: (e, t) => e[0] === t[0] && e[1] === t[1]
};

function ee(e, t) {
    let n = typeof e == `string` && b(e);
    if (n) return t.has(n) ? e : null
}

function te(e, t, n, r, i) {
    let a = N(e.pathname, r),
        o = N(t.pathname, r);
    return (n ? .exact ? a !== o : !(a.startsWith(o) && (a.length === o.length || a[o.length] === `/`))) || (n ? .includeSearch ? ? !0) && !m(e.search, t.search, !n ? .exact, n ? .explicitUndefined) ? !1 : !n ? .includeHash || i && e.hash === t.hash
}

function W(e, t, n) {
    let o = a(),
        s = B.useRef(null),
        c = B.useCallback(e => {
            if (s.current = e, typeof t == `function`) return t(e);
            t && (t.current = e)
        }, [t]),
        {
            activeOptions: l,
            to: u,
            preload: d,
            preloadDelay: f,
            hashScrollIntoView: p,
            replace: m,
            startTransition: h,
            resetScroll: g,
            viewTransition: _,
            ignoreBlocker: v,
            disabled: y,
            target: x,
            onClick: S,
            onBlur: C,
            onFocus: w,
            onMouseEnter: T,
            onMouseLeave: E,
            onTouchStart: D
        } = e,
        O = r(!!l ? .includeHash),
        [k, A, j] = V(e.search, e.params, l),
        [M, N] = B.useMemo(() => [e, { ...e
        }], [o, e.from, e._fromLocation, e.hash, e.to, k, A, e.state, e.mask, e.unsafeRelative]),
        P = B.useMemo(() => {
            let e = ee(u, o.protocolAllowlist);
            if (e !== void 0) {
                let t = [e ? ? void 0];
                return () => t
            }
            let t, n;
            return e => {
                M._fromLocation || (N._fromLocation = e);
                let r = o.buildLocation(N),
                    i = ie(r, o, y);
                return (!t || t[0] !== i) && (t = [i, !(y || i && !b(i)) && void 0], n = [i, !0]), t[1] !== void 0 && te(e, r, j, o.basepath, O) ? n : t
            }
        }, [j, y, O, M, N, o, u]),
        [F, I] = i(o.stores.location, P, U),
        L = I === void 0 && F,
        R = y || F === void 0,
        z = B.useRef(!1),
        W = e.reloadDocument || L || R ? !1 : d ? ? o.options.defaultPreload,
        G = f ? ? o.options.defaultPreloadDelay ? ? 0,
        K = B.useCallback(e => {
            let t = e ? .isIntersecting;
            if (!(t ? ? W === `intent`)) {
                t === !1 && Y(s);
                return
            }
            if (!G) {
                H(o, M);
                return
            }
            J.has(s) || J.set(s, setTimeout(() => {
                J.delete(s), H(o, M)
            }, G))
        }, [o, M, s, W, G]);
    B.useEffect(() => {
        if (!W) return;
        W === `render` && !z.current && (z.current = !0, H(o, M));
        let e = !0,
            t;
        return W === `viewport` && s.current && typeof IntersectionObserver == `function` && (t = new IntersectionObserver(t => {
            e && K(t.pop())
        }, {
            rootMargin: `100px`
        }), t.observe(s.current)), () => {
            e = !1, t ? .disconnect(), Y(s)
        }
    }, [o, M, W, K, s]);
    let q = ne(e, n);
    if (q.ref = t ? c : s, L) return q.href = L, q;
    let Z = e => {
            let t = x ? ? e.currentTarget.getAttribute(`target`);
            !R && !(e.metaKey || e.altKey || e.ctrlKey || e.shiftKey) && !e.defaultPrevented && (!t || t === `_self`) && e.button === 0 && (e.preventDefault(), o.navigate({ ...M,
                replace: m,
                resetScroll: g,
                hashScrollIntoView: p,
                startTransition: h,
                viewTransition: _,
                ignoreBlocker: v
            }))
        },
        Q = () => {
            W === `intent` && H(o, M)
        },
        $ = () => {
            W === `intent` && Y(s)
        };
    return q.onClick = X(S, Z), q.onBlur = X(C, $), q.onFocus = X(w, K), q.onMouseEnter = X(T, K), q.onMouseLeave = X(E, $), q.onTouchStart = X(D, Q), re(q, e, I, F, R, n)
}
var G = {},
    K = {
        className: `active`
    },
    q = new Set([`to`, `params`, `search`, `hash`, `state`, `mask`, `from`, `unsafeRelative`, `_fromLocation`, `reloadDocument`, `preload`, `preloadDelay`, `preloadIntentProximity`, `hashScrollIntoView`, `replace`, `startTransition`, `resetScroll`, `viewTransition`, `ignoreBlocker`, `activeProps`, `inactiveProps`, `activeOptions`, `_asChild`]);

function ne(e, t) {
    let n = {};
    for (let r in e) q.has(r) || r === `type` && t !== void 0 || r === `disabled` && t === `a` || (n[r] = e[r]);
    return n
}

function re(e, t, n, r, i, a) {
    let {
        activeProps: o,
        inactiveProps: c,
        className: l,
        style: u,
        target: d
    } = t, f = s(n ? o : c, {}) ? ? (n ? K : G);
    Object.assign(e, f), e.href = r, a !== `a` && (e.disabled = i), e.target = d;
    let p = f.style;
    (u || p) && (e.style = u && p ? { ...u,
        ...p
    } : u || p);
    let m = f.className;
    return (l || m) && (e.className = l ? m ? `${l} ${m}` : l : m), i && (e.role = `link`, e[`aria-disabled`] = !0), n && (e[`data-status`] = `active`, e[`aria-current`] = `page`), e
}
var J = new WeakMap,
    Y = e => {
        clearTimeout(J.get(e)), J.delete(e)
    },
    X = (e, t) => e ? n => n.defaultPrevented || (e(n), n.defaultPrevented || t(n)) : t;

function ie(e, t, n) {
    if (n) return;
    let r = e.maskedLocation ? ? e,
        i = r.external ? r.publicHref : t.history.createHref(r.publicHref) || `/`;
    if (!((r.external || i !== r.publicHref) && S(i, t.protocolAllowlist))) return i
}
var Z = B.memo(B.forwardRef((e, t) => {
    let n = e._asChild || `a`,
        r = W(e, t, n),
        i = typeof e.children == `function` ? e.children({
            isActive: r[`data-status`] === `active`
        }) : e.children;
    return B.createElement(n, r, i)
}), Q);

function Q(e, t) {
    let n = 0;
    for (let r in t)
        if (n++, e[r] !== t[r] && (!q.has(r) || !m(e[r], t[r], !1, !0))) return !1;
    for (let t in e) n--;
    return n === 0
}
export {
    d as C, o as S, f as T, b as _, P as a, S as b, j as c, u as d, E as f, s as g, T as h, R as i, y as l, D as m, k as n, M as o, m as p, F as r, A as s, Z as t, O as u, l as v, x as w, h as x, c as y
};