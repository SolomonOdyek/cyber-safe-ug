import {
    r as e
} from "./jsx-runtime-BkSabwWG.js";
import {
    t
} from "./react-DHmoMYoq.js";
var n = e(t(), 1),
    r = n.createContext(null);

function i(e) {
    return n.useContext(r)
}
export {
    r as n, i as t
};