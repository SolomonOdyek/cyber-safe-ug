import {
    r as e,
    t
} from "./jsx-runtime-BkSabwWG.js";
import {
    t as n
} from "./react-DHmoMYoq.js";
import {
    n as r
} from "./matchContext-CNtDuwuZ.js";
import {
    n as i,
    t as a
} from "./useSelector-7tZHjEZI.js";
import {
    t as o
} from "./useRouter-Dcm1jW_h.js";

function s(e) {
    return e ? .isNotFound === !0
}
var c = e(n(), 1),
    l = t(),
    u = class extends c.Component {
        constructor(...e) {
            super(...e), this.state = {
                error: 0
            }, this.reset = () => {
                this.setState({
                    error: 0
                })
            }
        }
        static getDerivedStateFromProps(e, t) {
            let n = e.getResetKey();
            return t.error && t.resetKey !== n ? {
                resetKey: n,
                error: 0
            } : {
                resetKey: n
            }
        }
        static getDerivedStateFromError(e) {
            return {
                error: [e]
            }
        }
        componentDidCatch(e, t) {
            this.props.onCatch ? .(e, t)
        }
        render() {
            let e = this.state.error;
            return e ? c.createElement(this.props.errorComponent ? ? d, {
                error: e[0],
                reset: this.reset
            }) : this.props.children
        }
    };

function d({
    error: e
}) {
    let [t, n] = c.useState(!1);
    return (0, l.jsxs)(`div`, {
        style: {
            padding: `.5rem`,
            maxWidth: `100%`
        },
        children: [(0, l.jsxs)(`div`, {
            style: {
                display: `flex`,
                alignItems: `center`,
                gap: `.5rem`
            },
            children: [(0, l.jsx)(`strong`, {
                style: {
                    fontSize: `1rem`
                },
                children: `Something went wrong!`
            }), (0, l.jsx)(`button`, {
                style: {
                    appearance: `none`,
                    fontSize: `.6em`,
                    border: `1px solid currentColor`,
                    padding: `.1rem .2rem`,
                    fontWeight: `bold`,
                    borderRadius: `.25rem`
                },
                onClick: () => n(e => !e),
                children: t ? `Hide Error` : `Show Error`
            })]
        }), (0, l.jsx)(`div`, {
            style: {
                height: `.25rem`
            }
        }), t ? (0, l.jsx)(`div`, {
            children: (0, l.jsx)(`pre`, {
                style: {
                    fontSize: `.7em`,
                    border: `1px solid red`,
                    borderRadius: `.25rem`,
                    padding: `.3rem`,
                    color: `red`,
                    overflow: `auto`
                },
                children: e ? .message ? (0, l.jsx)(`code`, {
                    children: e.message
                }) : null
            })
        }) : null]
    })
}

function f(e) {
    let t = o(),
        n = `not-found-${a(t.stores.location,e=>e.pathname)}-${a(t.stores.status)}`;
    return (0, l.jsx)(u, {
        getResetKey: () => n,
        onCatch: (t, n) => {
            if (s(t)) e.onCatch ? .(t, n);
            else throw t
        },
        errorComponent: ({
            error: t
        }) => {
            if (s(t)) return e.fallback ? .(t);
            throw t
        },
        children: e.children
    })
}

function p() {
    return (0, l.jsx)(`p`, {
        children: `Not Found`
    })
}

function m(e, t, n) {
    return t.options.notFoundComponent ? (0, l.jsx)(t.options.notFoundComponent, { ...n
    }) : e.options.defaultNotFoundComponent ? (0, l.jsx)(e.options.defaultNotFoundComponent, { ...n
    }) : (0, l.jsx)(p, {})
}

function h(e, t) {
    let n = t ? .options.pendingComponent ? ? e.options.defaultPendingComponent;
    return n ? (0, l.jsx)(n, {}) : null
}
var g = (e, t) => e[0] === t[0] && e[1] === t[1],
    _ = (e, t, n) => !t.isRoot || t.options.shellComponent || t.options.wrapInSuspense || n === !1 || n === `data-only` || !e.ssr,
    v = c.memo(function({
        routeId: e
    }) {
        let t = o();
        return (0, l.jsx)(y, {
            router: t,
            match: a(t.stores.getMatchStore(e))
        })
    });

function y({
    router: e,
    match: t
}) {
    let n = e.routesById[t.routeId],
        a = h(e, n),
        o = n.options.errorComponent ? ? e.options.defaultErrorComponent,
        d = n.options.onCatch ? ? e.options.defaultOnCatch,
        p = n.isRoot ? n.options.notFoundComponent ? ? e.options.notFoundRoute ? .options.component : n.options.notFoundComponent,
        m = t.ssr === !1 || t.ssr === `data-only`,
        g = _(e, n, t.ssr) && (n.options.wrapInSuspense ? ? a ? ? (n.options.errorComponent ? .preload || m)),
        v = (0, l.jsx)(b, {
            match: t
        });
    m && (v = (0, l.jsx)(i, {
        fallback: a,
        children: v
    })), p && (v = (0, l.jsx)(f, {
        fallback: e => {
            if (e.routeId ? ? = t.routeId, e.routeId !== t.routeId) throw e;
            return c.createElement(p, e)
        },
        children: v
    })), o && (v = (0, l.jsx)(u, {
        getResetKey: () => t,
        errorComponent: o,
        onCatch: (e, n) => {
            if (s(e)) throw e.routeId ? ? = t.routeId, e;
            d ? .(e, n)
        },
        children: v
    })), g && (v = (0, l.jsx)(c.Suspense, {
        fallback: a,
        children: v
    }));
    let y = n.isRoot ? n.options.shellComponent : void 0;
    return (0, l.jsx)(r.Provider, {
        value: t.routeId,
        children: y ? (0, l.jsxs)(y, {
            children: [v, null]
        }) : (0, l.jsxs)(l.Fragment, {
            children: [v, null]
        })
    })
}
var b = c.memo(function({
        match: e
    }) {
        let t = o(),
            n = e.routeId,
            r = t.routesById[n],
            i = c.useMemo(() => {
                let i = (r.options.remountDeps ? ? t.options.defaultRemountDeps) ? .({
                    routeId: n,
                    loaderDeps: e.loaderDeps,
                    params: e._strictParams,
                    search: e._strictSearch
                });
                return i ? JSON.stringify(i) : void 0
            }, [n, e.loaderDeps, e._strictParams, e._strictSearch, r.options.remountDeps, t.options.defaultRemountDeps]),
            a = c.useMemo(() => {
                let e = r.options.component ? ? t.options.defaultComponent;
                return e ? (0, l.jsx)(e, {}, i) : (0, l.jsx)(x, {})
            }, [i, r.options.component, t.options.defaultComponent]);
        if (e.status === `pending`) {
            if (t.ssr && !_(t, r, e.ssr)) return a;
            if (t._tx) throw t._tx[5];
            return h(t, r)
        }
        if (e.status === `notFound`) return m(t, r, e.error);
        if (e.status === `error`) throw e.error;
        return a
    }),
    x = c.memo(function() {
        let e = o(),
            t = c.useContext(r),
            n, i, s; {
            let r = e.stores.getMatchStore(t);
            [n, i] = a(r, e => [!!e._notFound, e.error], {
                compare: g
            }), s = a(e.stores.ids, e => e[e.indexOf(t) + 1])
        }
        if (n) return m(e, e.routesById[t], i);
        if (!s) return null;
        let u = (0, l.jsx)(v, {
            routeId: s
        });
        return t === `__root__` ? (0, l.jsx)(c.Suspense, {
            fallback: h(e),
            children: u
        }) : u
    });
export {
    s as a, u as i, x as n, h as r, v as t
};