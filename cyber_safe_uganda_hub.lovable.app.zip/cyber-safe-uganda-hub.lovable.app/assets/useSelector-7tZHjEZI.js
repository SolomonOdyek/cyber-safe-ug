import {
    n as e,
    r as t,
    t as n
} from "./jsx-runtime-BkSabwWG.js";
import {
    t as r
} from "./react-DHmoMYoq.js";
var i = t(r(), 1),
    a = n(),
    o = () => !0,
    s = () => !1;

function c({
    children: e,
    fallback: t = null
}) {
    return (0, a.jsx)(i.Fragment, {
        children: l() ? e : t
    })
}

function l(e = !0) {
    return i.useSyncExternalStore(u, o, e ? s : o)
}

function u() {
    return () => {}
}
var d = e((e => {
        var t = r();

        function n(e, t) {
            return e === t && (e !== 0 || 1 / e == 1 / t) || e !== e && t !== t
        }
        var i = typeof Object.is == `function` ? Object.is : n,
            a = t.useState,
            o = t.useEffect,
            s = t.useLayoutEffect,
            c = t.useDebugValue;

        function l(e, t) {
            var n = t(),
                r = a({
                    inst: {
                        value: n,
                        getSnapshot: t
                    }
                }),
                i = r[0].inst,
                l = r[1];
            return s(function() {
                i.value = n, i.getSnapshot = t, u(i) && l({
                    inst: i
                })
            }, [e, n, t]), o(function() {
                return u(i) && l({
                    inst: i
                }), e(function() {
                    u(i) && l({
                        inst: i
                    })
                })
            }, [e]), c(n), n
        }

        function u(e) {
            var t = e.getSnapshot;
            e = e.value;
            try {
                var n = t();
                return !i(e, n)
            } catch {
                return !0
            }
        }

        function d(e, t) {
            return t()
        }
        var f = typeof window > `u` || window.document === void 0 || window.document.createElement === void 0 ? d : l;
        e.useSyncExternalStore = t.useSyncExternalStore === void 0 ? f : t.useSyncExternalStore
    })),
    f = e(((e, t) => {
        t.exports = d()
    })),
    p = e((e => {
        var t = r(),
            n = f();

        function i(e, t) {
            return e === t && (e !== 0 || 1 / e == 1 / t) || e !== e && t !== t
        }
        var a = typeof Object.is == `function` ? Object.is : i,
            o = n.useSyncExternalStore,
            s = t.useRef,
            c = t.useEffect,
            l = t.useMemo,
            u = t.useDebugValue;
        e.useSyncExternalStoreWithSelector = function(e, t, n, r, i) {
            var d = s(null);
            if (d.current === null) {
                var f = {
                    hasValue: !1,
                    value: null
                };
                d.current = f
            } else f = d.current;
            d = l(function() {
                function e(e) {
                    if (!o) {
                        if (o = !0, s = e, e = r(e), i !== void 0 && f.hasValue) {
                            var t = f.value;
                            if (i(t, e)) return c = t
                        }
                        return c = e
                    }
                    if (t = c, a(s, e)) return t;
                    var n = r(e);
                    return i !== void 0 && i(t, n) ? (s = e, t) : (s = e, c = n)
                }
                var o = !1,
                    s, c, l = n === void 0 ? null : n;
                return [function() {
                    return e(t())
                }, l === null ? void 0 : function() {
                    return e(l())
                }]
            }, [t, n, r, i]);
            var p = o(e, d[0], d[1]);
            return c(function() {
                f.hasValue = !0, f.value = p
            }, [p]), u(p), p
        }
    })),
    m = e(((e, t) => {
        t.exports = p()
    }))();

function h(e, t) {
    return e === t
}

function g(e, t = e => e, n) {
    let r = n ? .compare ? ? h,
        a = (0, i.useCallback)(t => {
            let {
                unsubscribe: n
            } = e.subscribe(t);
            return n
        }, [e]),
        o = (0, i.useCallback)(() => e.get(), [e]);
    return (0, m.useSyncExternalStoreWithSelector)(a, o, o, t, r)
}
export {
    c as n, l as r, g as t
};