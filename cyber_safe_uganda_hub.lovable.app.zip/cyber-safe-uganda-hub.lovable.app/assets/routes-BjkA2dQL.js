import {
    t as e
} from "./jsx-runtime-BkSabwWG.js";
import {
    t
} from "./link-C3yd_qY1.js";
import {
    C as n,
    a as r,
    c as i,
    d as a,
    h as o,
    l as s,
    s as c,
    x as l
} from "./index-DoGJ9nw6.js";
import {
    n as u
} from "./PageHero-Byh1HYIY.js";
var d = l(`arrow-right`, [
        [`path`, {
            d: `M5 12h14`,
            key: `1ays0h`
        }],
        [`path`, {
            d: `m12 5 7 7-7 7`,
            key: `xquz4c`
        }]
    ]),
    f = l(`building-2`, [
        [`path`, {
            d: `M10 12h4`,
            key: `a56b0p`
        }],
        [`path`, {
            d: `M10 8h4`,
            key: `1sr2af`
        }],
        [`path`, {
            d: `M14 21v-3a2 2 0 0 0-4 0v3`,
            key: `1rgiei`
        }],
        [`path`, {
            d: `M6 10H4a2 2 0 0 0-2 2v7a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-2`,
            key: `secmi2`
        }],
        [`path`, {
            d: `M6 21V5a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v16`,
            key: `16ra0t`
        }]
    ]),
    p = l(`graduation-cap`, [
        [`path`, {
            d: `M21.42 10.922a1 1 0 0 0-.019-1.838L12.83 5.18a2 2 0 0 0-1.66 0L2.6 9.08a1 1 0 0 0 0 1.832l8.57 3.908a2 2 0 0 0 1.66 0z`,
            key: `j76jl0`
        }],
        [`path`, {
            d: `M22 10v6`,
            key: `1lu8f3`
        }],
        [`path`, {
            d: `M6 12.5V16a6 3 0 0 0 12 0v-3.5`,
            key: `1r8lef`
        }]
    ]),
    m = l(`heart-handshake`, [
        [`path`, {
            d: `M19.414 14.414C21 12.828 22 11.5 22 9.5a5.5 5.5 0 0 0-9.591-3.676.6.6 0 0 1-.818.001A5.5 5.5 0 0 0 2 9.5c0 2.3 1.5 4 3 5.5l5.535 5.362a2 2 0 0 0 2.879.052 2.12 2.12 0 0 0-.004-3 2.124 2.124 0 1 0 3-3 2.124 2.124 0 0 0 3.004 0 2 2 0 0 0 0-2.828l-1.881-1.882a2.41 2.41 0 0 0-3.409 0l-1.71 1.71a2 2 0 0 1-2.828 0 2 2 0 0 1 0-2.828l2.823-2.762`,
            key: `17lmqv`
        }]
    ]),
    h = l(`user`, [
        [`path`, {
            d: `M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2`,
            key: `975kel`
        }],
        [`circle`, {
            cx: `12`,
            cy: `7`,
            r: `4`,
            key: `17ys0d`
        }]
    ]),
    g = `/assets/hero-training-DNge9k4M.jpg`,
    _ = e(),
    v = [{
        icon: f,
        title: `Small businesses`,
        text: `Protect customer data, money and reputation.`
    }, {
        icon: p,
        title: `Schools`,
        text: `Safer students, teachers and parents online.`
    }, {
        icon: h,
        title: `Individuals`,
        text: `Keep your phone, accounts and savings safe.`
    }, {
        icon: m,
        title: `Community organisations`,
        text: `Awareness for SACCOs, churches and groups.`
    }];

function y() {
    let {
        data: e
    } = n(a), {
        data: l
    } = n(c);
    return (0, _.jsxs)(_.Fragment, {
        children: [(0, _.jsxs)(`section`, {
            className: `relative overflow-hidden bg-hero text-navy-foreground`,
            children: [(0, _.jsx)(`div`, {
                className: `circuit-grid absolute inset-0 opacity-40`,
                "aria-hidden": `true`
            }), (0, _.jsxs)(`div`, {
                className: `relative mx-auto grid max-w-7xl items-center gap-10 px-4 py-16 sm:px-6 lg:grid-cols-2 lg:py-24`,
                children: [(0, _.jsxs)(`div`, {
                    children: [(0, _.jsx)(`p`, {
                        className: `font-mono text-xs uppercase tracking-[0.2em] text-cyan`,
                        children: `Cybersecurity awareness · Uganda`
                    }), (0, _.jsxs)(`h1`, {
                        className: `mt-4 text-4xl font-bold leading-tight sm:text-5xl lg:text-6xl`,
                        children: [`Stay safe online. `, (0, _.jsx)(`span`, {
                            className: `text-gradient-cyan`,
                            children: `Learn it in person.`
                        })]
                    }), (0, _.jsx)(`p`, {
                        className: `mt-5 max-w-xl text-lg text-navy-foreground/75`,
                        children: `Practical, jargon-free training on phishing, mobile money fraud, passwords and privacy — delivered face-to-face to businesses, schools and communities across Uganda.`
                    }), (0, _.jsxs)(`div`, {
                        className: `mt-8 flex flex-col gap-3 sm:flex-row`,
                        children: [(0, _.jsx)(o, {
                            asChild: !0,
                            variant: `hero`,
                            size: `lg`,
                            children: (0, _.jsxs)(t, {
                                to: `/programs`,
                                children: [`Book Cybersecurity Training `, (0, _.jsx)(d, {})]
                            })
                        }), (0, _.jsx)(o, {
                            asChild: !0,
                            variant: `heroOutline`,
                            size: `lg`,
                            children: (0, _.jsx)(t, {
                                to: `/resources`,
                                children: `Explore Resources`
                            })
                        })]
                    })]
                }), (0, _.jsxs)(`div`, {
                    className: `relative`,
                    children: [(0, _.jsx)(`div`, {
                        className: `absolute -inset-3 rounded-3xl bg-cyan/20 blur-2xl`,
                        "aria-hidden": `true`
                    }), (0, _.jsx)(`img`, {
                        src: g,
                        width: 1600,
                        height: 1008,
                        alt: `A trainer leading an in-person cybersecurity workshop with a group of participants`,
                        className: `relative rounded-2xl border border-cyan/30 object-cover shadow-glow`
                    })]
                })]
            })]
        }), (0, _.jsxs)(u, {
            children: [(0, _.jsx)(`h2`, {
                className: `text-3xl font-bold`,
                children: `Who we train`
            }), (0, _.jsx)(`div`, {
                className: `mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4`,
                children: v.map(e => (0, _.jsxs)(`div`, {
                    className: `rounded-xl border bg-card p-6 shadow-card`,
                    children: [(0, _.jsx)(e.icon, {
                        className: `h-7 w-7 text-chart-1`,
                        "aria-hidden": `true`
                    }), (0, _.jsx)(`h3`, {
                        className: `mt-3 font-semibold`,
                        children: e.title
                    }), (0, _.jsx)(`p`, {
                        className: `mt-1 text-sm text-muted-foreground`,
                        children: e.text
                    })]
                }, e.title))
            })]
        }), (0, _.jsx)(`section`, {
            className: `bg-secondary`,
            children: (0, _.jsxs)(u, {
                children: [(0, _.jsxs)(`div`, {
                    className: `flex flex-wrap items-end justify-between gap-4`,
                    children: [(0, _.jsxs)(`div`, {
                        children: [(0, _.jsx)(`h2`, {
                            className: `text-3xl font-bold`,
                            children: `Practical services`
                        }), (0, _.jsx)(`p`, {
                            className: `mt-2 text-muted-foreground`,
                            children: `Everything focused on the threats Ugandans actually face.`
                        })]
                    }), (0, _.jsx)(o, {
                        asChild: !0,
                        variant: `outline`,
                        children: (0, _.jsx)(t, {
                            to: `/services`,
                            children: `All services`
                        })
                    })]
                }), (0, _.jsx)(`div`, {
                    className: `mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3`,
                    children: r.map(e => (0, _.jsxs)(`div`, {
                        className: `flex gap-4 rounded-xl bg-card p-5 shadow-card`,
                        children: [(0, _.jsx)(`div`, {
                            className: `flex h-11 w-11 shrink-0 items-center justify-center rounded-lg bg-navy text-cyan`,
                            children: (0, _.jsx)(e.icon, {
                                className: `h-5 w-5`,
                                "aria-hidden": `true`
                            })
                        }), (0, _.jsxs)(`div`, {
                            children: [(0, _.jsx)(`h3`, {
                                className: `font-semibold`,
                                children: e.title
                            }), (0, _.jsx)(`p`, {
                                className: `text-sm text-muted-foreground`,
                                children: e.text
                            })]
                        })]
                    }, e.title))
                })]
            })
        }), (0, _.jsxs)(u, {
            children: [(0, _.jsxs)(`div`, {
                className: `flex flex-wrap items-end justify-between gap-4`,
                children: [(0, _.jsx)(`h2`, {
                    className: `text-3xl font-bold`,
                    children: `Popular training`
                }), (0, _.jsx)(o, {
                    asChild: !0,
                    variant: `outline`,
                    children: (0, _.jsx)(t, {
                        to: `/programs`,
                        children: `Full catalogue`
                    })
                })]
            }), (0, _.jsx)(`div`, {
                className: `mt-8 grid gap-4 md:grid-cols-3`,
                children: (e ? ? []).slice(0, 3).map(e => (0, _.jsxs)(`div`, {
                    className: `flex flex-col rounded-xl border bg-card p-6 shadow-card`,
                    children: [(0, _.jsx)(`span`, {
                        className: `font-mono text-xs uppercase text-muted-foreground`,
                        children: e.category
                    }), (0, _.jsx)(`h3`, {
                        className: `mt-2 text-xl font-semibold`,
                        children: e.title
                    }), (0, _.jsx)(`p`, {
                        className: `mt-2 flex-1 text-sm text-muted-foreground`,
                        children: e.summary
                    }), (0, _.jsxs)(`p`, {
                        className: `mt-4 font-semibold`,
                        children: [s(e.price_ugx), ` `, (0, _.jsxs)(`span`, {
                            className: `text-xs font-normal text-muted-foreground`,
                            children: [e.price_unit, `*`]
                        })]
                    }), (0, _.jsx)(o, {
                        asChild: !0,
                        className: `mt-4`,
                        children: (0, _.jsx)(t, {
                            to: `/book`,
                            search: {
                                program: e.id
                            },
                            children: `Request booking`
                        })
                    })]
                }, e.id))
            }), (0, _.jsx)(`p`, {
                className: `mt-4 text-xs text-muted-foreground`,
                children: `* Prices are illustrative and may be updated by the CyberSafe team.`
            })]
        }), l && l.length > 0 && (0, _.jsx)(`section`, {
            className: `bg-secondary`,
            children: (0, _.jsxs)(u, {
                children: [(0, _.jsx)(`h2`, {
                    className: `text-3xl font-bold`,
                    children: `Upcoming events`
                }), (0, _.jsx)(`div`, {
                    className: `mt-6 grid gap-4 md:grid-cols-2`,
                    children: l.slice(0, 2).map(e => (0, _.jsxs)(t, {
                        to: `/events`,
                        className: `rounded-xl bg-card p-6 shadow-card hover:ring-2 hover:ring-ring`,
                        children: [(0, _.jsx)(`p`, {
                            className: `font-mono text-xs text-chart-1`,
                            children: i(e.starts_at, !0)
                        }), (0, _.jsx)(`h3`, {
                            className: `mt-1 text-lg font-semibold`,
                            children: e.title
                        }), (0, _.jsx)(`p`, {
                            className: `text-sm text-muted-foreground`,
                            children: e.location
                        })]
                    }, e.id))
                })]
            })
        }), (0, _.jsx)(`section`, {
            className: `bg-hero text-navy-foreground`,
            children: (0, _.jsxs)(`div`, {
                className: `mx-auto flex max-w-7xl flex-col items-start justify-between gap-6 px-4 py-14 sm:px-6 md:flex-row md:items-center`,
                children: [(0, _.jsxs)(`div`, {
                    children: [(0, _.jsx)(`h2`, {
                        className: `text-3xl font-bold`,
                        children: `Need a programme for your organisation?`
                    }), (0, _.jsx)(`p`, {
                        className: `mt-2 text-navy-foreground/75`,
                        children: `Tell us about your team and we'll propose a session that fits.`
                    })]
                }), (0, _.jsx)(o, {
                    asChild: !0,
                    variant: `hero`,
                    size: `lg`,
                    children: (0, _.jsx)(t, {
                        to: `/consultation`,
                        children: `Request a consultation`
                    })
                })]
            })
        })]
    })
}
export {
    y as component
};