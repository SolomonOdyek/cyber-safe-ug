import {
    r as e
} from "./jsx-runtime-BkSabwWG.js";
import {
    t
} from "./react-DHmoMYoq.js";
var n = `__root__`,
    r = e(t(), 1),
    i = r.createContext(void 0),
    a = r.createContext(void 0);
export {
    i as n, n as r, a as t
};