import {
    r as e
} from "./jsx-runtime-BkSabwWG.js";
import {
    t
} from "./react-DHmoMYoq.js";
import {
    T as n
} from "./link-C3yd_qY1.js";
import {
    n as r,
    t as i
} from "./matchContext-CNtDuwuZ.js";
import {
    t as a
} from "./useSelector-7tZHjEZI.js";
import {
    t as o
} from "./useRouter-Dcm1jW_h.js";

function s(e) {
    e.statusCode = e.statusCode || e.code || 307;
    let t = new Headers(e.headers);
    e.href && t.get(`Location`) === null && t.set(`Location`, e.href);
    let n = new Response(null, {
        status: e.statusCode,
        headers: t
    });
    if (n.options = e, e.throw) throw n;
    return n
}

function c(e) {
    return e instanceof Response && !!e.options
}

function l(e) {
    if (typeof e == `object` && e && e.isSerializedRedirect) return s(e)
}

function u() {
    throw Error(`Invariant failed`)
}
var d = e(t(), 1),
    f = d.use,
    p = d.useLayoutEffect,
    m = {};

function h(e, t) {
    let r = d.useRef();
    return i => {
        let a = e ? .select ? e.select(i) : i;
        return e ? .structuralSharing ? ? t.options.defaultStructuralSharing ? r.current = n(r.current, a) : a
    }
}

function g(e) {
    let t = o(),
        n = d.useContext(e.from ? i : r),
        s = e.from ? ? n,
        c = t.stores.getMatchStore(s),
        l = h(e, t),
        f = a(c, e => e ? l(e) : m);
    if (f !== m) return f;
    (e.shouldThrow ? ? !0) && u()
}
export {
    u as a, s as c, p as i, h as n, c as o, f as r, l as s, g as t
};