import {
    t as e
} from "./jsx-runtime-BkSabwWG.js";
var t = e();

function n({
    eyebrow: e,
    title: n,
    children: r
}) {
    return (0, t.jsxs)(`section`, {
        className: `relative overflow-hidden bg-hero text-navy-foreground`,
        children: [(0, t.jsx)(`div`, {
            className: `circuit-grid absolute inset-0 opacity-40`,
            "aria-hidden": `true`
        }), (0, t.jsxs)(`div`, {
            className: `relative mx-auto max-w-7xl px-4 py-16 sm:px-6 sm:py-20`,
            children: [(0, t.jsx)(`p`, {
                className: `font-mono text-xs uppercase tracking-[0.2em] text-cyan`,
                children: e
            }), (0, t.jsx)(`h1`, {
                className: `mt-3 max-w-3xl text-4xl font-bold sm:text-5xl`,
                children: n
            }), r && (0, t.jsx)(`div`, {
                className: `mt-4 max-w-2xl text-lg text-navy-foreground/75`,
                children: r
            })]
        })]
    })
}

function r({
    children: e,
    className: n = ``
}) {
    return (0, t.jsx)(`section`, {
        className: `mx-auto max-w-7xl px-4 py-14 sm:px-6 ${n}`,
        children: e
    })
}
export {
    r as n, n as t
};