(() => {
    ((i, Ve, Sr, Tr = 50, ht = 50 * 1024, Ne = 512 * 1024, _e = 100, Er = 5 * 1024 * 1024, ve = 50, gt = 600 * 1e3, wr = 2e3) => {
        const yt = i.__lovableEvents || {};
        if (yt.__userAppEventsSdkVersion) return;
        const _ = i.document,
            De = i.navigator || {},
            bt = De.webdriver === !0 || !!i.Cypress || !!i.__nightmare,
            k = i.performance || {
                now: () => Date.now()
            },
            M = i.location || {
                pathname: "",
                href: "",
                search: ""
            },
            Z = () => i.setTimeout || (typeof setTimeout == "function" ? setTimeout : null),
            ee = () => i.clearTimeout || (typeof clearTimeout == "function" ? clearTimeout : null);
        if ((e => e === "/__codex_token_check" || e.startsWith("/__l5e/"))(M.pathname)) return;
        const E = _ && _.currentScript,
            _t = E ? {
                kind: E.getAttribute("data-artifact-kind") || null,
                id: E.getAttribute("data-artifact-id") || null,
                commit_sha: E.getAttribute("data-commit-sha") || null,
                context_token: E.getAttribute("data-context-token") || null
            } : {},
            vt = E ? .getAttribute("data-replay") || null,
            ze = (() => {
                try {
                    const e = new URL(E ? .src || "").pathname,
                        t = e.lastIndexOf("/__l5e/");
                    return t > 0 ? e.slice(0, t) : ""
                } catch {
                    return ""
                }
            })(),
            xr = E ? .getAttribute("data-track-url") || `${ze}/__l5e/trackevents`,
            Rr = E ? .getAttribute("data-replay-url") || `${ze}/__l5e/replay`,
            Mr = E ? .getAttribute("data-replay-script-url") || `${ze}/__l5e/rrweb-record.js`,
            kt = e => {
                const t = typeof e == "string" ? Number(e) : 0;
                return !Number.isFinite(t) || t <= 0 ? 0 : t >= 1 ? 1 : t
            },
            $e = kt(E ? .getAttribute("data-replay-sample-rate") || null),
            qe = kt(E ? .getAttribute("data-replay-crash-sample-rate") || null),
            Lr = E ? .getAttribute("data-autocapture") === "1",
            St = e => {
                const t = new Uint8Array(e);
                if (i.crypto && typeof i.crypto.getRandomValues == "function") i.crypto.getRandomValues(t);
                else
                    for (let r = 0; r < t.length; r++) t[r] = Math.floor(Math.random() * 256);
                return t
            },
            Tt = e => Array.from(e, t => t.toString(16).padStart(2, "0")).join(""),
            S = () => {
                if (i.crypto && typeof i.crypto.randomUUID == "function") return i.crypto.randomUUID();
                const e = St(16);
                e[6] = e[6] & 15 | 64, e[8] = e[8] & 63 | 128;
                const t = Tt(e);
                return `${t.slice(0,8)}-${t.slice(8,12)}-${t.slice(12,16)}-${t.slice(16,20)}-${t.slice(20)}`
            },
            Ge = e => {
                const t = St(e);
                return t.every(r => r === 0) && (t[t.length - 1] = 1), Tt(t)
            },
            Et = () => ({
                traceId: Ge(16),
                rootSpanId: Ge(8)
            }),
            He = S();
        let Je = null,
            ke = S(),
            We = 0,
            te = Et(),
            Ke = 0,
            H = null;
        const wt = [1e4, 3e4, 6e4, 3e5];
        let Ye = 0,
            Se = null;
        const Ir = 144e5;
        let Xe = 0,
            Te = !1;
        const xt = 18e5;
        let J = null,
            Ee = 0,
            Rt = 0,
            re = !1;
        const Mt = (e => {
                let t = 2166136261;
                for (let r = 0; r < e.length; r++) t ^= e.charCodeAt(r), t = Math.imul(t, 16777619);
                return (t >>> 0) / 4294967296
            })(He),
            V = $e > 0 && Mt < $e,
            Ar = qe > 0 && Mt < qe,
            Lt = V || Ar,
            It = V ? $e : qe;
        let g = null,
            L = 0,
            Qe = 0,
            v = !1,
            we = null,
            P = 0,
            ne = 0,
            oe = 0,
            ae = null,
            $ = 0,
            le = null,
            xe = null,
            se = !1,
            Re = !1,
            N = !1,
            j = V,
            C = V ? "sampled" : null,
            Me = null,
            Le = null,
            Ze = !1;
        const T = [],
            Pr = Math.max(_e, _e * ve),
            jr = ["[data-lovable-mask]", "[data-sensitive]", "[data-private]", "[data-auth]", "[data-payment]", "[contenteditable]", "[autocomplete]", "[name*='email' i]", "[name*='phone' i]", "[name*='address' i]", "[name*='token' i]", "[name*='secret' i]"].join(","),
            Cr = ["canvas", "embed", "iframe", "object", "video", "[data-lovable-block]", ".rr-block", "[data-payment]", "[data-auth]", "[data-private]"].join(","),
            Fr = "[data-lovable-ignore],.rrweb-ignore",
            Ur = "h1,h2,h3,h4,h5,h6,p,span,a,button,li,label,dt,dd,th,figcaption,small,strong,em",
            At = e => e.replace(/[^\s]/gu, "*"),
            Or = (e, t) => {
                if (typeof t ? .tagName == "string" && t.tagName.toUpperCase() === "STYLE") return e;
                const r = t && typeof t.closest == "function" ? t.closest.bind(t) : null;
                return r ? .("[data-lovable-unmask]") ? .matches ? .(Ur) && !r ? .(`.rr-mask,${jr}`) ? e : At(e)
            },
            q = [];
        let ie = null,
            Ie = !1,
            Pt = !1,
            jt = !1,
            W = !1,
            Ct = 0,
            Br = 0;
        const Ft = Math.max(1, Tr),
            Vr = 5,
            Nr = 200,
            Dr = /^project\.[a-z][a-z0-9_]{0,63}(\.[a-z][a-z0-9_]{0,63})*$/u,
            zr = e => {
                const t = Sr[e];
                return typeof t == "number" && t > 0 ? t : Dr.test(e) ? 1 : null
            },
            Ut = typeof TextEncoder == "function" ? new TextEncoder : null,
            D = e => Ut ? Ut.encode(e).length : e.length,
            Ot = e => JSON.stringify({
                envelope_schema_version: 1,
                batch_id: S(),
                sent_at: new Date().toISOString(),
                sdk: {
                    name: "lovable-user-app-events",
                    version: Ve
                },
                automated: bt,
                artifact: _t,
                events: e
            }),
            Bt = e => {
                const t = i.console;
                t && typeof t.debug == "function" && t.debug(`[lovable-analytics] ${e}`)
            },
            $r = (e, t) => {
                if ((e === 403 || e === 404) && t === "rejected") {
                    Ie = !0, q.length = 0, jt || (jt = !0, Bt(`events disabled for this page load (HTTP ${e})`));
                    return
                }
                Pt || (Pt = !0, Bt(`event batch rejected (HTTP ${e})`))
            },
            Vt = 64 * 1024,
            Nt = 16 * 1024;
        let ce = 0,
            et = 0;
        const Dt = () => {
                ce -= et, et = 0
            },
            zt = (e, t, r) => {
                const n = D(t),
                    l = Vt - (r.reserveBytes || 0),
                    a = !!r.keepalive && ce + n <= l;
                a && (ce += n);
                let s = a;
                const m = () => {
                        s && (s = !1, ce -= n)
                    },
                    b = i.Blob || (typeof Blob == "function" ? Blob : null);
                if (a && r.beacon && De.sendBeacon && b) try {
                    if (De.sendBeacon(e, new b([t], {
                            type: "application/json"
                        }))) {
                        et += n, s = !1;
                        return
                    }
                } catch {}
                const x = i.fetch || (typeof fetch == "function" ? fetch : null);
                if (!x) {
                    m(), r.onNetworkError ? .();
                    return
                }
                try {
                    Promise.resolve(x(e, {
                        method: "POST",
                        headers: {
                            "content-type": "application/json"
                        },
                        body: t,
                        ...a ? {
                            keepalive: !0
                        } : {}
                    })).then(U => {
                        m(), r.onResponse ? .(U)
                    }, () => {
                        m(), r.onNetworkError ? .()
                    }).catch(() => {})
                } catch {
                    m(), r.onNetworkError ? .()
                }
            },
            qr = (e, t) => {
                const r = e.filter(l => {
                    try {
                        return JSON.stringify(l), !0
                    } catch {
                        return !1
                    }
                });
                let n = 0;
                for (; n < r.length;) {
                    let l = r.length,
                        a = Ot(r.slice(n, l));
                    const s = Vt - ce,
                        m = t && s >= Nt ? Math.min(ht, s) : ht;
                    for (; l - n > 1 && D(a) > m;) l = n + Math.max(1, Math.floor((l - n) / 2)), a = Ot(r.slice(n, l));
                    zt(xr, a, {
                        keepalive: !0,
                        beacon: t,
                        onResponse: b => {
                            !b || b.ok !== !1 || $r(b.status, b.headers ? .get ? .("x-lovable-events") ? ? null)
                        }
                    }), n = l
                }
            },
            tt = (e, t, r) => g ? JSON.stringify({
                envelope_schema_version: 1,
                replay_schema_version: 1,
                replay_id: g,
                chunk_id: t,
                chunk_sequence: r,
                sent_at: new Date().toISOString(),
                sdk: {
                    name: "lovable-user-app-events",
                    version: Ve
                },
                automated: bt,
                artifact: _t,
                session_id: He,
                page_view_id: ke,
                events: e
            }) : null,
            Gr = e => {
                const t = tt([e], "00000000-0000-4000-8000-000000000000", P);
                return !!t && D(t) <= Ne
            },
            $t = e => {
                const t = e && typeof e == "object" ? e : null;
                return typeof t ? .type == "number" ? t.type : null
            },
            rt = () => Math.max(0, k.now() - Qe),
            qt = () => {
                if (!le) return;
                const e = ee();
                e && e(le), le = null
            },
            Ae = () => {
                if (!xe) return;
                const e = ee();
                e && e(xe), xe = null
            },
            nt = () => {
                try {
                    we ? .()
                } catch {} finally {
                    we = null, se = !1
                }
            },
            Hr = e => {
                switch (e) {
                    case "recorder_script_failed":
                        return "recorder_script";
                    case "recorder_start_failed":
                        return "recorder_start";
                    case "recorder_runtime_error":
                        return "recorder_runtime";
                    case "missing_full_snapshot":
                    case "full_snapshot_too_large":
                        return "snapshot";
                    case "upload_failed":
                        return "upload";
                    default:
                        return null
                }
            },
            Gt = (e, t, r, n, l, a) => {
                const s = Hr(t);
                s && w("lovable.replay_error", {
                    replay_id: e,
                    reason: t,
                    stage: s,
                    recorder: "rrweb",
                    sample_rate: It,
                    event_count: r,
                    duration_ms: n,
                    chunk_count: l,
                    uploaded_bytes: a
                })
            },
            Jr = () => !C || C === "sampled" ? {} : {
                capture_reason: C,
                trigger_event_id: Me,
                trigger_event_name: Le
            },
            Ht = (e, t, r, n, l, a, s) => {
                w("lovable.session_replay", {
                    replay_id: e,
                    status: t,
                    reason: r,
                    recorder: "rrweb",
                    sample_rate: It,
                    event_count: n,
                    duration_ms: l,
                    chunk_count: a,
                    uploaded_bytes: s,
                    ...Jr()
                }), Gt(e, r, n, l, a, s)
            },
            ot = (e, t) => {
                g && Ht(g, e, t, L, rt(), P, $)
            },
            at = () => j || C === "sampled",
            lt = (e, t, r, n, l, a, s) => {
                at() ? Ht(e, t, r, n, l, a, s) : Gt(e, r, n, l, a, s)
            },
            F = (e, t = !1) => {
                !g || v || (nt(), Ae(), t && (T.length = 0, qt()), at() && ot("stopped", e), v = !0)
            },
            Jt = () => {
                if (!(!g || v)) {
                    if (!j) {
                        nt(), Ae();
                        return
                    }
                    F("duration_limit", !0)
                }
            },
            Wt = e => {
                !g || v || C === "client_error" || (j = !0, C = "client_error", Me = e, Le = "lovable.client_error", Kt())
            },
            Wr = () => T.length > 0 || P > 0 || $ > 0,
            Kt = () => !g || v || C !== "client_error" || Ze || !N || !Wr() ? !1 : (Ze = !0, ot("captured", "client_error"), K(!0), !0),
            Yt = e => {
                if (oe > 0) {
                    ae = e;
                    return
                }
                F(e, !0)
            },
            Xt = () => {
                if (oe--, v || oe > 0 || !ae) return;
                const e = ae;
                ae = null, ne > 0 ? Qt() : F(e, !0)
            },
            K = (e = !1) => {
                if (qt(), !(!j || !g || T.length === 0 || !N))
                    for (; !v && T.length > 0;) {
                        let t = Math.min(T.length, _e);
                        const r = S(),
                            n = P;
                        let l = tt(T.slice(0, t), r, n);
                        for (; l && t > 1 && D(l) > Ne;) t = Math.max(1, Math.floor(t / 2)), l = tt(T.slice(0, t), r, n);
                        if (!l) return;
                        const a = D(l);
                        if (a > Ne) {
                            T.shift(), L = Math.max(0, L - 1);
                            continue
                        }
                        const s = P - ne;
                        if (s >= ve || $ + a > Er) {
                            Yt(s >= ve ? "chunk_limit" : "size_limit");
                            return
                        }
                        if (T.splice(0, t), P++, $ += a, oe++, zt(Rr, l, {
                                keepalive: e,
                                reserveBytes: Nt,
                                onResponse: m => {
                                    const b = m ? .status === 429;
                                    if (b && (ne++, $ -= a, L = Math.max(0, L - t)), Xt(), b || m && m.ok !== !1) return;
                                    const x = m ? .headers ? .get ? .("x-lovable-events");
                                    F(x === "unavailable" ? "upload_unavailable" : x === "rejected" ? "upload_rejected" : "upload_failed", !0)
                                },
                                onNetworkError: () => {
                                    F("upload_failed", !0), Xt()
                                }
                            }), v) return;
                        if (P - ne >= ve) {
                            Yt("chunk_limit");
                            return
                        }
                    }
            },
            Qt = () => {
                if (le) return;
                const e = Z();
                if (!e) {
                    K();
                    return
                }
                le = e(K, wr)
            },
            Kr = () => {
                if (!ie) return;
                const e = ee();
                e && e(ie), ie = null
            },
            Y = (e = !1) => {
                if (Kr(), Ie || q.length === 0) return;
                const t = q.splice(0, Ft);
                qr(t, e || W), q.length > 0 && Zt()
            },
            Zt = () => {
                if (ie || Ie) return;
                const e = Z();
                if (!e) {
                    Y();
                    return
                }
                ie = e(Y, 250)
            },
            Yr = () => {
                H === null && (H = k.now())
            },
            Pe = () => {
                H = null
            },
            ue = () => {
                const e = ee();
                Se !== null && e && e(Se), Se = null
            },
            Xr = () => {
                if (H !== null) {
                    const t = k.now();
                    Ke += t - H, H = t
                }
                const e = Math.round(Ke);
                return Ke = 0, e
            },
            pe = e => {
                const t = Xr();
                if (t <= 0) return;
                Xe += t;
                const r = Xe >= Ir;
                r && (Te = !0, Pe(), ue()), w("lovable.page_engagement", {
                    reason: r ? "capped" : e,
                    engagement_time_ms: t
                })
            },
            er = () => {
                ue();
                const e = Z();
                if (!e) return;
                const t = wt[Math.min(Ye, wt.length - 1)];
                Se = e(() => {
                    Ye++, pe("threshold"), !Te && er()
                }, t)
            },
            st = () => {
                const e = ee();
                J !== null && (e && e(J), Ee += Math.max(0, k.now() - Rt)), J = null
            },
            tr = () => {
                st(), Ee = 0
            },
            rr = () => {
                if (J !== null || !_ || _.visibilityState === "hidden" || _.hasFocus ? .() !== !1) return;
                const e = Z();
                e && (Rt = k.now(), J = e(() => {
                    J = null, Ee = xt, re = !0, pe("unfocused"), Pe(), ue()
                }, Math.max(0, xt - Ee)))
            },
            fe = () => {
                _ && _.visibilityState === "hidden" || re || Te || (Yr(), Ye = 0, er(), rr())
            },
            nr = () => (pe("navigation"), Xe = 0, Te = !1, fe(), ke = S(), te = Et(), We = 0, ke),
            Qr = e => e === "lovable.page_viewed" ? {
                trace_id: te.traceId,
                span_id: te.rootSpanId
            } : {
                trace_id: te.traceId,
                span_id: Ge(8),
                parent_span_id: te.rootSpanId
            },
            Zr = e => e === "lovable.client_error" || e === "lovable.resource_error" || e === "lovable.replay_error",
            en = (e, t, r = {}) => {
                if (Ie) return null;
                if (Zr(e) && ++Br > Nr) return e === "lovable.client_error" && Wt(null), null;
                const n = e === "lovable.client_error" && Ct < Vr;
                n && Ct++;
                const l = S(),
                    a = g && !v && (j || e === "lovable.client_error") ? g : null,
                    s = {
                        event_id: l,
                        event_name: e,
                        event_schema_version: t,
                        event_time: new Date().toISOString(),
                        session_id: He,
                        page_view_id: ke,
                        ...Qr(e),
                        properties: r
                    };
                return a && (s.replay_id = a), n ? q.unshift(s) : q.push(s), e === "lovable.client_error" && Wt(l), n || q.length >= Ft ? Y() : Zt(), l
            },
            w = (e, t = {}) => {
                const r = typeof e == "string" ? zr(e) : null;
                return r === null ? null : en(e, r, t)
            };
        let de = M.pathname;
        const tn = (e, t = {}) => (e === "lovable.page_viewed" && (nr(), typeof t.url_path == "string" && (de = t.url_path)), w(e, t)),
            rn = /(^|[^a-z0-9_.-])([a-z0-9_.-]*(token|secret|password|passwd|key)|token_hash|code|email)(=|%3d)/iu,
            it = e => rn.test(e) ? "/" : e,
            ct = e => {
                try {
                    const t = new URL(e, M.href);
                    return t.protocol === "http:" || t.protocol === "https:" ? it(t.pathname) : t.pathname
                } catch {
                    return null
                }
            },
            or = e => {
                try {
                    return new URL(e, M.href).host.replace(/^www\./iu, "")
                } catch {
                    return null
                }
            },
            nn = e => {
                try {
                    return new URL(e, M.href).protocol.replace(/:$/u, "")
                } catch {
                    return null
                }
            },
            on = [
                ["utm_source", "campaign_source"],
                ["utm_medium", "campaign_medium"],
                ["utm_campaign", "campaign_name"],
                ["utm_term", "campaign_term"],
                ["utm_content", "campaign_content"],
                ["utm_id", "campaign_id"]
            ],
            an = [
                ["gclid"],
                ["dclid"],
                ["gbraid"],
                ["wbraid"],
                ["msclkid"],
                ["ttclid"],
                ["twclid"],
                ["li_fat_id"],
                ["fbclid"],
                ["oppref"],
                ["ko_click_id"],
                ["irclickid", "im_ref"],
                ["via"]
            ],
            ln = 128,
            sn = (e, t) => {
                const r = {};
                try {
                    const n = new URLSearchParams(typeof e == "string" ? e.replace(/;/gu, "&") : "");
                    for (const [s, m] of on) {
                        const b = n.get(s);
                        if (typeof b != "string") continue;
                        const x = b.trim();
                        x && D(x) <= ln && (r[m] = x)
                    }
                    const l = s => {
                            const m = n.get(s);
                            return typeof m == "string" && m.trim() !== ""
                        },
                        a = an.filter(s => s.some(l)).map(([s]) => s);
                    if (!a.includes("via") && typeof t == "string") {
                        const s = new URLSearchParams(t.slice(1)).get("via");
                        typeof s == "string" && s.trim() !== "" && a.push("via")
                    }
                    a.length > 0 && (r.campaign_click_id_types = a)
                } catch {
                    return {}
                }
                return r
            },
            ar = (e, t) => {
                let r = e;
                for (; r && D(JSON.stringify(r)) > t;) r = r.slice(0, Math.floor(r.length * .8));
                return r
            },
            me = (e, t) => {
                if (typeof e != "string") return null;
                const r = e.replace(/\s+/gu, " ").trim();
                if (!r) return null;
                if (r.length <= t) return r;
                const n = Array.from(r);
                return n.length > t ? n.slice(0, t).join("") : r
            },
            cn = 2048,
            lr = () => me(it(M.pathname || "/"), cn) || "/",
            ut = e => {
                const t = e && typeof e == "object" ? e : null,
                    r = a => typeof a == "string" ? a : typeof a == "number" || typeof a == "boolean" || typeof a == "bigint" ? String(a) : null,
                    n = r(t ? .stack),
                    l = r(t ? .message) || r(e) || "Unknown error";
                return {
                    message: ar(l.slice(0, 2e3), 2048),
                    name: r(t ? .name),
                    stack: n ? ar(n.slice(0, 8e3), 8192) : null
                }
            },
            sr = 1e3,
            un = 1e4,
            ir = 10,
            je = new Map,
            he = [],
            cr = (e, t) => {
                for (const [r, n] of je) t - n >= sr && je.delete(r);
                je.set(e, t)
            },
            pt = (e, t = !0) => {
                t && nr();
                const r = M.pathname,
                    n = {
                        url_path: it(r),
                        navigation_type: e
                    };
                typeof _ ? .referrer == "string" && _.referrer && (n.referrer_host = or(_.referrer) ? ? "", n.referrer_path = ct(_.referrer) ? ? ""), Object.assign(n, sn(M.search, M.hash)), de = r, cr(r, k.now()), w("lovable.page_viewed", n)
            },
            ft = e => {
                M.pathname !== de && pt(e)
            },
            pn = () => {
                const e = M.pathname;
                if (e === de) return;
                const t = k.now(),
                    r = je.get(e);
                if (r !== void 0 && t - r < sr && (he.push(t), he.length > ir + 1 && he.shift(), he.length > ir && t - he[0] < un)) {
                    de = e, cr(e, t);
                    return
                }
                pt("replace_state")
            },
            ur = () => {
                const e = vt === "rrweb" && Lt && i.rrweb && typeof i.rrweb.record == "function" ? i.rrweb.record : null;
                if (!(!e || g)) {
                    g = S(), Qe = k.now(), v = !1, P = 0, ne = 0, oe = 0, ae = null, $ = 0, se = !1, N = !1, j = V, C = V ? "sampled" : null, Me = null, Le = null, Ze = !1;
                    try {
                        const t = e({
                            emit(n) {
                                if (v || !n || typeof n != "object") return;
                                if (rt() >= gt) {
                                    Jt();
                                    return
                                }
                                const l = $t(n);
                                if (!Gr(n)) {
                                    l === 2 && !N && F("full_snapshot_too_large", !0);
                                    return
                                }
                                if (!(l === 3 && !N)) {
                                    for (l === 2 && (N = !0), L += 1, T.push(n); !j && T.length > Pr;) {
                                        const a = T.findIndex(s => $t(s) !== 2);
                                        T.splice(a >= 0 ? a : 0, 1), L = Math.max(0, L - 1)
                                    }
                                    Kt() || j && (T.length >= _e ? K() : Qt())
                                }
                            },
                            blockClass: "rr-block",
                            blockSelector: Cr,
                            collectFonts: !1,
                            ignoreClass: "rrweb-ignore",
                            ignoreSelector: Fr,
                            inlineImages: !1,
                            maskAllInputs: !0,
                            maskInputFn: At,
                            maskInputOptions: {
                                checkbox: !1,
                                color: !1,
                                date: !0,
                                "datetime-local": !0,
                                email: !0,
                                month: !0,
                                number: !0,
                                password: !0,
                                radio: !1,
                                range: !1,
                                search: !0,
                                select: !0,
                                tel: !0,
                                text: !0,
                                textarea: !0,
                                time: !0,
                                url: !0,
                                week: !0
                            },
                            maskTextClass: "rr-mask",
                            maskTextFn: Or,
                            maskTextSelector: "*",
                            recordAfter: "load",
                            recordCanvas: !1,
                            recordCrossOriginIframes: !1
                        });
                        if (v) {
                            if (typeof t == "function") try {
                                t()
                            } catch {}
                            return
                        }
                        se = !0, typeof t == "function" && (we = t);
                        const r = Z();
                        r && typeof e.takeFullSnapshot == "function" && r(() => {
                            if (!(!g || v)) try {
                                e.takeFullSnapshot ? .(!1)
                            } catch {}
                        }, 1e3), r && (xe = r(Jt, gt)), at() && ot("started", "recorder_available")
                    } catch {
                        g && lt(g, "stopped", "recorder_start_failed", L, rt(), P, $), g = null, L = 0, Qe = 0, v = !1, N = !1, j = V, C = V ? "sampled" : null, Me = null, Le = null, we = null, se = !1, Ae()
                    }
                }
            },
            fn = () => {
                if (vt !== "rrweb" || !Lt || g || Re) return;
                if (i.rrweb && typeof i.rrweb.record == "function") {
                    ur();
                    return
                }
                const e = _ ? .head;
                if (!_ ? .createElement || !e ? .appendChild) return;
                const t = _.createElement("script");
                Re = !0, t.async = !0, t.src = Mr, t.onload = () => {
                    if (Re = !1, !i.rrweb || typeof i.rrweb.record != "function") {
                        lt(S(), "stopped", "recorder_script_failed", 0, 0, 0, 0);
                        return
                    }
                    ur()
                }, t.onerror = () => {
                    Re = !1, lt(S(), "stopped", "recorder_script_failed", 0, 0, 0, 0)
                }, e.appendChild(t)
            },
            dn = e => {
                if (!(!g || v)) {
                    if (nt(), Ae(), !N) {
                        F("missing_full_snapshot", !0);
                        return
                    }
                    K(!0), v || F(e)
                }
            },
            mn = e => {
                if (!g || v) return;
                const t = e && typeof e == "object" ? e : null,
                    r = t ? .error && typeof t.error == "object" ? t.error : null,
                    n = typeof t ? .filename == "string" ? t.filename : "",
                    l = typeof r ? .stack == "string" ? r.stack : "";
                (n.includes("/__l5e/rrweb-record") || l.includes("/__l5e/rrweb-record")) && F("recorder_runtime_error", !0)
            },
            hn = (e, t) => {
                const n = {
                    CLS: [.1, .25],
                    FCP: [1800, 3e3],
                    INP: [200, 500],
                    LCP: [2500, 4e3],
                    TTFB: [800, 1800]
                }[e];
                return !n || t <= n[0] ? "good" : t <= n[1] ? "needs-improvement" : "poor"
            },
            gn = e => e === "CLS" ? "score" : "millisecond",
            I = (e, t) => {
                const r = e[t];
                return typeof r == "number" && Number.isFinite(r) ? r : null
            },
            Ce = (e, t) => {
                const r = i.PerformanceObserver;
                if (!r) return !1;
                const n = r.supportedEntryTypes;
                if (Array.isArray(n) && !n.includes(e)) return !1;
                try {
                    return new r(a => {
                        const s = typeof a.getEntries == "function" ? a.getEntries() : [];
                        for (const m of s) m && typeof m == "object" && t(m)
                    }).observe(e === "event" ? {
                        type: e,
                        buffered: !0,
                        durationThreshold: 40
                    } : {
                        type: e,
                        buffered: !0
                    }), !0
                } catch {
                    return !1
                }
            },
            yn = () => {
                const e = lr(),
                    t = (u, f, A = f, dt = S()) => {
                        !Number.isFinite(f) || f < 0 || w("lovable.web_vital", {
                            url_path: e,
                            metric: u,
                            value: f,
                            unit: gn(u),
                            delta: A,
                            rating: hn(u, f),
                            id: dt,
                            navigation_type: "initial_load"
                        })
                    };
                let r = !1,
                    n = null,
                    l = 0,
                    a = 0,
                    s = !1;
                const m = {},
                    b = {},
                    x = u => (m[u] = m[u] || S(), m[u]),
                    U = (u, f) => {
                        if (b[u] === f) return;
                        const A = b[u];
                        b[u] = f, t(u, f, A === void 0 ? f : f - A, x(u))
                    },
                    ge = typeof k.getEntriesByType == "function" ? k.getEntriesByType("navigation") : [],
                    O = ge[0] && typeof ge[0] == "object" ? ge[0] : null,
                    B = O ? I(O, "responseStart") : null,
                    Fe = O ? I(O, "requestStart") : null,
                    Ue = O ? I(O, "fetchStart") : null,
                    X = Fe ? ? Ue;
                B !== null && X !== null && B >= X && t("TTFB", B - X), Ce("paint", u => {
                    if (r || u.name !== "first-contentful-paint") return;
                    const f = I(u, "startTime");
                    f !== null && (r = !0, t("FCP", f))
                }), Ce("largest-contentful-paint", u => {
                    n = I(u, "startTime") ? ? I(u, "renderTime") ? ? I(u, "loadTime") ? ? n
                });
                const Oe = Ce("layout-shift", u => {
                    if (u.hadRecentInput === !0) return;
                    const f = I(u, "value");
                    f !== null && (l += f)
                });
                return Ce("event", u => {
                    const f = I(u, "interactionId");
                    if (f === null || f <= 0) return;
                    const A = I(u, "duration");
                    A !== null && A > a && (a = A)
                }), (u = !1) => {
                    s || (n !== null && U("LCP", n), Oe && U("CLS", l), a > 0 && U("INP", a), u && (s = !0))
                }
            },
            pr = (e, t) => {
                const r = i.history,
                    n = r && r[e];
                !r || typeof n != "function" || (r[e] = function(...l) {
                    const a = n.apply(this, l);
                    return t(), a
                })
            },
            bn = e => {
                const t = e && typeof e == "object" && !Array.isArray(e) ? e : {},
                    r = typeof t.mechanism == "string" ? t.mechanism : "manual",
                    n = typeof t.severity == "string" ? t.severity : "error";
                return {
                    mechanism: ["manual", "onerror", "unhandledrejection", "react_error_boundary"].includes(r) ? r : "manual",
                    handled: typeof t.handled == "boolean" ? t.handled : !0,
                    severity: ["error", "warning", "info"].includes(n) ? n : "error"
                }
            };
        i.__lovableEvents = Object.assign(yt, {
            __userAppEventsSdkVersion: Ve,
            track: tn,
            flush: () => Y(),
            identify(e) {
                const t = e && typeof e == "object" ? e : null;
                Je = typeof t ? .user_id == "string" ? t.user_id : null
            },
            getIdentity() {
                return {
                    app_user_id_hash_available: !!Je
                }
            },
            getReplay() {
                return {
                    replay_id: g,
                    active: !!g && !v && se,
                    event_count: L
                }
            },
            resetIdentity() {
                Je = null
            },
            captureException(e, t = {}, r = {}) {
                const n = ut(e),
                    l = bn(r);
                let a = t && typeof t == "object" && !Array.isArray(t) ? t : {};
                try {
                    D(JSON.stringify(a)) > 4096 && (a = {})
                } catch {
                    a = {}
                }
                w("lovable.client_error", {
                    occurrence_id: S(),
                    ...n,
                    ...l,
                    context: a
                })
            },
            startSpan(e, t = {}) {
                const r = new Date().toISOString(),
                    n = k.now();
                return {
                    end(l = "ok") {
                        w("lovable.frontend_span", {
                            name: e,
                            start_time: r,
                            status: l,
                            duration_ms: Math.max(0, k.now() - n),
                            attributes: t
                        })
                    }
                }
            }
        }), i.addEventListener && i.addEventListener("error", mn, !0), fn();
        const fr = yn();
        if (i.addEventListener && (i.addEventListener("error", e => {
                const t = e && typeof e == "object" ? e : null,
                    r = t ? .target && typeof t.target == "object" ? t.target : null;
                let n = null;
                if (r && r !== i && (typeof r.src == "string" ? n = r.src : typeof r.href == "string" && (n = r.href)), n !== null) {
                    const a = typeof r ? .tagName == "string" ? r.tagName.toLowerCase() : "unknown",
                        s = or(n);
                    w("lovable.resource_error", {
                        resource_type: a,
                        url_host: s || nn(n) || "unknown",
                        failure_type: "load_error",
                        element: a,
                        url_path: s ? ct(n) : null,
                        mechanism: "resource_load",
                        handled: !1,
                        severity: "error"
                    });
                    return
                }
                const l = ut(t ? .error || t ? .message);
                w("lovable.client_error", {
                    occurrence_id: S(),
                    ...l,
                    filename: typeof t ? .filename == "string" ? ct(t.filename) : null,
                    lineno: typeof t ? .lineno == "number" ? t.lineno : null,
                    colno: typeof t ? .colno == "number" ? t.colno : null,
                    mechanism: "onerror",
                    handled: !1,
                    severity: "error"
                })
            }, !0), i.addEventListener("unhandledrejection", e => {
                const r = ut((e && typeof e == "object" ? e : null) ? .reason);
                w("lovable.client_error", {
                    occurrence_id: S(),
                    ...r,
                    mechanism: "unhandledrejection",
                    handled: !1,
                    severity: "error"
                })
            }), i.addEventListener("pagehide", () => {
                W = !0, fr(!0), dn("pagehide"), pe("pagehide"), Pe(), ue(), st(), Y(!0)
            }), i.addEventListener("blur", () => rr()), i.addEventListener("focus", () => {
                tr(), re && (re = !1, fe())
            }), i.addEventListener("pageshow", e => {
                (e && typeof e == "object" ? e.persisted : !1) === !0 && (W = !1, Dt(), tr(), re = !1, fe())
            }), i.addEventListener("popstate", () => ft("popstate")), i.addEventListener("hashchange", () => ft("hashchange")), Lr)) {
            const b = {
                    select: !0,
                    textarea: !0,
                    input: !0
                },
                x = {
                    button: !0,
                    a: !0,
                    input: !0,
                    select: !0,
                    textarea: !0,
                    summary: !0
                },
                U = {
                    button: !0,
                    link: !0,
                    menuitem: !0,
                    menuitemcheckbox: !0,
                    menuitemradio: !0,
                    tab: !0,
                    switch: !0,
                    checkbox: !0,
                    radio: !0,
                    option: !0
                },
                ge = {
                    header: !0,
                    footer: !0,
                    main: !0,
                    nav: !0,
                    aside: !0,
                    section: !0,
                    article: !0,
                    form: !0
                },
                O = typeof Symbol < "u" && typeof Symbol.for == "function" ? Symbol.for("__jsxSource__") : null,
                B = o => o && typeof o == "object" && typeof o.tagName == "string" ? o : null,
                Fe = {};
            for (const o of "html body div span main header footer nav aside section article form p a button input select textarea label fieldset legend optgroup option datalist output progress meter ul ol li dl dt dd table thead tbody tfoot tr td th caption col colgroup h1 h2 h3 h4 h5 h6 br hr pre blockquote figure figcaption small strong em b i u s q cite abbr code kbd samp var mark sub sup time address details summary dialog menu picture source track canvas iframe object embed param map area img video audio template slot noscript script style link meta title base head ins del ruby rt rp bdi bdo wbr data hgroup search fencedframe svg path g circle rect line polyline polygon ellipse text textpath tspan defs use symbol clippath mask pattern lineargradient radialgradient stop filter foreignobject marker image view desc animate animatetransform animatemotion set fegaussianblur feoffset feblend fecolormatrix fecomposite feflood femerge femergenode femorphology fetile feturbulence fedropshadow fedisplacementmap".split(" ")) Fe[o] = !0;
            const Ue = {};
            for (const o of "button link menuitem menuitemcheckbox menuitemradio tab switch checkbox radio option combobox listbox textbox searchbox slider spinbutton treeitem gridcell row columnheader rowheader tooltip dialog alertdialog navigation main banner contentinfo complementary region form search article list listitem table grid tree menu menubar toolbar tabpanel tablist progressbar status alert log timer none presentation".split(" ")) Ue[o] = !0;
            const X = {};
            for (const o of "button submit reset checkbox radio text password email number tel url search date time datetime-local month week color file range hidden image".split(" ")) X[o] = !0;
            const Oe = (o, c) => o !== null && c[o.toLowerCase()] === !0 ? o.toLowerCase() : null,
                u = o => {
                    const c = String(o.tagName).toLowerCase();
                    return Fe[c] === !0 ? c : "x"
                },
                f = (o, c) => {
                    if (typeof o.getAttribute != "function") return null;
                    const d = o.getAttribute(c);
                    return typeof d == "string" && d !== "" ? d : null
                },
                A = (o, c) => typeof o.getAttribute == "function" && typeof o.getAttribute(c) == "string",
                dt = o => {
                    if (b[u(o)] === !0) return null;
                    const c = o.childNodes;
                    if (!c || typeof c.length != "number") return null;
                    const d = c;
                    let p = "";
                    for (let y = 0; y < d.length; y++) {
                        const h = d[y];
                        if (h && h.nodeType === 3 && typeof h.nodeValue == "string" && (p += h.nodeValue), p.length > 200) return null
                    }
                    return p === "" ? null : p
                },
                _n = o => me(f(o, "aria-label") || f(o, "title") || f(o, "alt") || dt(o), 64),
                vn = (o, c, d) => {
                    const p = o.children;
                    if (!p || typeof p.length != "number") return "";
                    const y = p;
                    let h = 0,
                        R = 0;
                    for (let z = 0; z < y.length; z++) {
                        const Q = B(y[z]);
                        !Q || u(Q) !== d || (R++, Q === c && (h = R))
                    }
                    return h > 0 ? ":" + h : ""
                },
                kn = o => {
                    const c = [];
                    let d = o;
                    for (let y = 0; d && y < 32; y++) {
                        const h = u(d);
                        if (!h || h === "html") break;
                        const R = B(d.parentElement);
                        if (c.unshift(R && h !== "body" ? h + vn(R, d, h) : h), h === "body" || !R) break;
                        d = R
                    }
                    if (c.length === 0) return null;
                    let p = c.join(">");
                    for (; p.length > 1024 && c.length > 1;) c.shift(), p = c.join(">");
                    return p.length > 1024 ? p.slice(p.length - 1024) : p
                },
                Sn = o => {
                    if (O === null) return null;
                    const c = o[O];
                    if (!c || typeof c != "object") return null;
                    const d = c.displayName;
                    return typeof d == "string" && d !== "" ? d : null
                },
                Tn = o => {
                    if (x[u(o)] === !0) return !0;
                    const c = f(o, "role");
                    return c !== null && U[c.toLowerCase()] === !0
                },
                En = (o, c) => {
                    const d = typeof o.composedPath == "function" ? o.composedPath() : null;
                    if (Array.isArray(d)) {
                        const h = [];
                        for (const R of d) {
                            if (h.length >= c) return {
                                nodes: h,
                                complete: !1
                            };
                            const z = B(R);
                            z && h.push(z)
                        }
                        return {
                            nodes: h,
                            complete: !0
                        }
                    }
                    const p = [];
                    let y = B(o.target);
                    for (; y;) {
                        if (p.length >= c) return {
                            nodes: p,
                            complete: !1
                        };
                        p.push(y), y = B(y.parentElement)
                    }
                    return {
                        nodes: p,
                        complete: !0
                    }
                },
                dr = o => o === "mouse" || o === "touch" || o === "pen",
                wn = 2e3,
                xn = 300;
            let mt = "",
                mr = 0;
            const hr = o => mt !== "" && k.now() - mr <= o ? mt : "";
            i.addEventListener("pointerdown", o => {
                try {
                    const c = o;
                    if (c.isTrusted !== !0) return;
                    const d = typeof c.pointerType == "string" ? c.pointerType : "";
                    dr(d) && (mt = d, mr = k.now())
                } catch {}
            }, !0);
            const gr = o => Math.round(o * 1e3) / 1e3,
                ye = o => typeof o == "number" && isFinite(o) ? o : null;
            i.addEventListener("click", o => {
                try {
                    if (!o || typeof o != "object") return;
                    const c = o;
                    if (c.isTrusted !== !0 || We >= 200) return;
                    const d = En(c, 512);
                    if (!d.complete) return;
                    let p = null,
                        y = null;
                    for (let Be = 0; Be < d.nodes.length; Be++) {
                        const be = d.nodes[Be];
                        if (A(be, "data-lov-no-capture")) return;
                        if (!(Be >= 32)) {
                            if (p === null) {
                                Tn(be) && (p = be);
                                continue
                            }
                            y === null && ge[u(be)] === !0 && (y = be)
                        }
                    }
                    if (p === null) return;
                    const h = typeof c.pointerType == "string" ? c.pointerType : "",
                        R = ye(c.detail) ? ? 0,
                        z = R === 0 ? hr(xn) : "",
                        Q = dr(h) ? h : z || (R === 0 ? "keyboard" : hr(wn) || "unknown");
                    let yr = null,
                        br = null;
                    const _r = ye(c.clientX),
                        vr = ye(c.clientY),
                        G = typeof p.getBoundingClientRect == "function" ? p.getBoundingClientRect() : null;
                    Q !== "keyboard" && G && _r !== null && vr !== null && G.width > 0 && G.height > 0 && (yr = gr(Math.min(1, Math.max(0, (_r - G.left) / G.width))), br = gr(Math.min(1, Math.max(0, (vr - G.top) / G.height))));
                    const kr = i;
                    w("lovable.element_clicked", {
                        url_path: lr(),
                        element_tag: u(p),
                        interaction_type: Q,
                        element_role: Oe(f(p, "role"), Ue),
                        element_type: Oe(f(p, "type"), X),
                        element_label: _n(p),
                        element_path: kn(p),
                        component_name: me(Sn(p), 64),
                        section_tag: y ? me(u(y), 64) : null,
                        section_label: y ? me(f(y, "aria-label"), 64) : null,
                        offset_x: yr,
                        offset_y: br,
                        viewport_width: ye(kr.innerWidth),
                        viewport_height: ye(kr.innerHeight)
                    }), We++
                } catch {}
            }, !0)
        }
        _ && typeof _.addEventListener == "function" && _.addEventListener("visibilitychange", () => {
            if (_.visibilityState === "hidden") {
                W = !0, fr(), K(!0), pe("hidden"), Pe(), ue(), st(), Y(!0), W = !1;
                return
            }
            W = !1, Dt(), fe()
        }), pr("pushState", () => ft("push_state")), pr("replaceState", pn), w("lovable.session_started", {
            reason: "new_session"
        }), pt("initial_load", !1), fe()
    })(window, "0.3.0-automated-flag", {
        "lovable.webmcp_tool_invoked": 1,
        "lovable.session_started": 1,
        "lovable.page_viewed": 1,
        "lovable.client_error": 1,
        "lovable.frontend_span": 1,
        "lovable.interaction": 1,
        "lovable.element_clicked": 1,
        "lovable.form_submitted": 1,
        "lovable.resource_error": 1,
        "lovable.session_replay": 1,
        "lovable.replay_error": 1,
        "lovable.web_vital": 1,
        "lovable.page_engagement": 1
    }, 50, 51200);
})();